# TG 引流中心（宝塔 PHP 版）

这是一个无需 Composer 的纯 PHP + MySQL 项目，适合上传到宝塔面板。管理员可以配置 Telegram 机器人、邀请门槛、任意奖品名称、按钮和消息文案，并通过加密库存自动发放奖励。

## 已包含的功能

- 管理员账号密码登录、CSRF 防护和安全会话 Cookie
- Bot Token 与奖品内容使用 AES-256-GCM 加密保存
- 机器人两个主按钮，默认是“领取捷克 eSIM”和“查看邀请链接”，后台可任意改名
- 用户首次进入自动生成唯一邀请码和 `t.me` 专属邀请链接
- 好友通过专属链接进入后，必须先加入指定频道并验证成功，才计为 1 个有效邀请
- 未验证用户不能查看或传播自己的专属邀请码
- Telegram 标记为机器人的账号会被直接拒绝
- 邀请门槛后台可设置，例如每 3 人、5 人或任意人数获得一次奖励
- 支持多轮奖励：达到 3、6、9 人时分别产生第 1、2、3 次奖励
- 奖品库存批量导入，每行一条；机器人内实时显示剩余库存数量
- 开启自动发放后，用户达标会自动取一条库存并私发
- 库存不足时保留待发记录，管理员可补库存后手动发送
- 用户、邀请、奖励、库存和失败原因均可在后台查看
- 一键测试 Bot Token、一键设置 Telegram Webhook
- Cloudflare CDN 场景使用固定 HTTPS 域名，不依赖 Host 或转发协议头

## 宝塔面板部署

1. 在宝塔的软件商店安装 **Nginx、MySQL 5.7+/8.0 和 PHP 8.1+**。
2. 确认 PHP 扩展已启用：`pdo_mysql`、`curl`、`openssl`、`mbstring`。
3. 在宝塔创建站点和一个 MySQL 数据库，记下数据库名、用户名和密码。
4. 上传并解压整个项目目录，例如：`/www/wwwroot/tg-referral-php`。
5. 在宝塔站点设置中，把“网站目录 / 运行目录”指向：
 
   ```text
   /www/wwwroot/tg-referral-php/public
   ```

   `app`、`database` 和 `storage` 必须位于网站根目录之外，不能把整个项目目录直接设为公开目录。

6. 先让 `app` 目录可写，访问 `https://你的域名/install.php`，填写 Cloudflare HTTPS 域名、数据库和管理员账号。
7. 安装成功后，确认生成了 `app/config.php`，把该文件权限改为 **600**，把 `app` 目录恢复为普通只读权限。
8. 把机器人添加为需要验证的频道管理员。只有管理员身份才能可靠调用 `getChatMember` 验证其他用户。
9. 登录后台，在“机器人配置”保存 Bot Token；填写频道 ID 和频道加入链接，然后点击“检查机器人频道权限”。
10. 点击“测试连接”，再点击“设置 Webhook”。Webhook 会同时接收普通消息和频道验证按钮事件。
11. 在“奖励库存”中每行输入一份奖品内容并导入。机器人会实时显示可用库存。

## Cloudflare CDN 设置

- SSL/TLS 加密模式建议使用 **完全（严格）**；源站安装有效证书或 Cloudflare Origin Certificate。
- 不要使用“灵活”SSL，否则后台 Cookie 和 Webhook 容易出现 HTTPS 判断或重定向问题。
- 创建缓存规则，对以下路径设置 **绕过缓存**：

  ```text
  /index.php*
  /login.php*
  /logout.php*
  /install.php*
  /webhook.php*
  ```

- 如果 Bot Fight Mode 或 WAF 对 Telegram Webhook 发起挑战，可为 `URI Path equals /webhook.php` 且 `Method equals POST` 建立跳过挑战规则。Webhook 仍会验证 Telegram 的秘密请求头。
- 不要启用会改写 HTML/JavaScript 的功能；静态 CSS/JS 可以正常走 CDN。
- Webhook 地址始终来自安装时填写的固定 `app_url`，不会信任可伪造的 `Host`、`X-Forwarded-Host` 或 `X-Forwarded-Proto`。

## 后台可配置内容

- Bot Token、机器人用户名
- 是否启用频道验证、频道 ID、频道链接和验证提示文案
- 奖品名称（不局限于捷克 eSIM）
- 每次奖励所需邀请人数
- 达标后是否自动发放
- 机器人两个按钮的文字
- 欢迎语、邀请进度通知、达标通知、发奖消息
- 消息变量：`{reward}`、`{required}`、`{count}`、`{remaining}`、`{stock}`、`{content}`
- 管理员密码

## 频道验证与防刷说明

- 公开频道 ID 可填写 `@channel_username`，加入链接填写 `https://t.me/channel_username`。
- 私有频道 ID 通常是 `-100...`，加入链接填写频道生成的私有邀请链接。
- 机器人必须是频道管理员，否则 Telegram 不保证能够查询其他用户的成员状态。
- 新用户通过邀请链接点击“开始”后，系统只保存一条待验证关系。验证通过之前，邀请人不会增加人数。
- 每个 Telegram 用户 ID 只能被记录一次，不能重复给不同邀请人贡献人数。
- Telegram Bot API 不提供用户手机号、设备指纹、真实身份或可靠的账号年龄，因此频道验证可以提高多号成本，但不能百分之百判断多个真实账号是否属于同一人。

## 从旧版升级

如果已经部署过不含频道验证的版本：

1. 先备份数据库和 `app/config.php`。
2. 上传新版文件，但保留原来的 `app/config.php`。
3. 在宝塔 phpMyAdmin 中对现有数据库执行：

   ```text
   database/upgrade-1.1-channel-verification.sql
   ```

4. 登录后台配置频道并重新点击“设置 Webhook”。

新安装用户不需要执行升级 SQL，安装向导会直接创建最新版数据库结构。

## 目录说明

```text
app/                 核心服务与安装后生成的 config.php
database/schema.sql  MySQL 数据库结构
public/              宝塔站点唯一公开目录
public/webhook.php   Telegram Webhook
storage/             预留的服务器存储目录
```

## 安全提醒

- 不要把 `app/config.php`、数据库密码或 Bot Token 发给他人。
- Cloudflare 与源站都应启用 HTTPS。
- 定期备份 MySQL；奖品内容依赖 `app/config.php` 中的 `encryption_key`，因此数据库和此文件必须一起备份。
- 如更换 `encryption_key`，旧 Token 和旧库存将无法解密。
- 安装脚本在检测到 `app/config.php` 后会停止安装并跳转登录页，避免重复初始化。
