<?php
declare(strict_types=1);

final class Crypto
{
    public static function encrypt(string $plainText, string $secret): string
    {
        $key = hash('sha256', $secret, true);
        $iv = random_bytes(12);
        $tag = '';
        $cipherText = openssl_encrypt($plainText, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag);
        if ($cipherText === false) {
            throw new RuntimeException('敏感内容加密失败');
        }
        return 'v1.' . base64_encode($iv) . '.' . base64_encode($tag) . '.' . base64_encode($cipherText);
    }

    public static function decrypt(string $payload, string $secret): string
    {
        $parts = explode('.', $payload, 4);
        if (count($parts) !== 4 || $parts[0] !== 'v1') {
            throw new RuntimeException('敏感内容格式无效');
        }
        [, $iv, $tag, $cipherText] = $parts;
        $plainText = openssl_decrypt(
            base64_decode($cipherText, true),
            'aes-256-gcm',
            hash('sha256', $secret, true),
            OPENSSL_RAW_DATA,
            base64_decode($iv, true),
            base64_decode($tag, true)
        );
        if ($plainText === false) {
            throw new RuntimeException('敏感内容解密失败，请检查加密密钥');
        }
        return $plainText;
    }

    public static function preview(string $content): string
    {
        $content = trim(preg_replace('/\s+/u', ' ', $content) ?? $content);
        $length = mb_strlen($content);
        if ($length <= 8) {
            return mb_substr($content, 0, 2) . '••••';
        }
        return mb_substr($content, 0, 4) . '••••' . mb_substr($content, -3);
    }
}
