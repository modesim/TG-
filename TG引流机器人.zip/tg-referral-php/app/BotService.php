<?php
declare(strict_types=1);

final class BotService
{
    private PDO $db;
    private array $config;
    private array $settings;
    private Telegram $telegram;

    public function __construct()
    {
        $this->db = db();
        $this->config = app_config();
        $this->settings = get_settings();
        if (empty($this->settings['bot_token_encrypted'])) {
            throw new RuntimeException('机器人尚未配置');
        }
        $token = Crypto::decrypt($this->settings['bot_token_encrypted'], $this->config['encryption_key']);
        $this->telegram = new Telegram($token);
    }

    public function telegram(): Telegram
    {
        return $this->telegram;
    }

    public function keyboard(): array
    {
        return [
            'keyboard' => [
                [['text' => $this->settings['button_claim_text']]],
                [['text' => $this->settings['button_link_text']]],
            ],
            'resize_keyboard' => true,
            'is_persistent' => true,
        ];
    }

    public function processUpdate(array $update): void
    {
        $updateId = (int)($update['update_id'] ?? 0);
        $message = $update['message'] ?? null;
        $callback = $update['callback_query'] ?? null;
        $from = is_array($callback) ? ($callback['from'] ?? null) : ($message['from'] ?? null);
        if ($updateId <= 0 || !is_array($from) || empty($from['id'])) {
            return;
        }
        $stmt = $this->db->prepare('INSERT IGNORE INTO bot_updates (update_id) VALUES (?)');
        $stmt->execute([$updateId]);
        if ($stmt->rowCount() === 0) {
            return;
        }

        if (!empty($from['is_bot'])) {
            if (is_array($callback) && !empty($callback['id'])) {
                $this->telegram->call('answerCallbackQuery', [
                    'callback_query_id' => $callback['id'],
                    'text' => '机器人账号不能参加此活动',
                    'show_alert' => true,
                ]);
            }
            return;
        }

        [$user, $created] = $this->findOrCreateUser($from);

        if (is_array($callback)) {
            if (($callback['data'] ?? '') === 'verify_channel') {
                $this->handleVerificationCallback($callback, $user);
            }
            return;
        }

        $text = trim((string)($message['text'] ?? ''));
        $chatId = (string)($message['chat']['id'] ?? $from['id']);

        $payload = null;
        if (preg_match('/^\/start(?:@\w+)?(?:\s+(.+))?$/iu', $text, $matches)) {
            $payload = isset($matches[1]) ? trim($matches[1]) : null;
            if ($created && $payload && empty($user['referred_by_user_id']) && empty($user['pending_referral_code'])) {
                $pendingCode = strtoupper(trim(preg_replace('/^ref_/i', '', $payload) ?? ''));
                if ($pendingCode !== '' && !hash_equals($user['invite_code'], $pendingCode)) {
                    $this->db->prepare('UPDATE users SET pending_referral_code = ? WHERE id = ? AND referred_by_user_id IS NULL')
                        ->execute([$pendingCode, $user['id']]);
                    $user['pending_referral_code'] = $pendingCode;
                }
            }
            if (!$this->ensureVerified($user, $chatId)) {
                return;
            }
            $this->telegram->sendMessage(
                $chatId,
                fill_template($this->settings['welcome_message'], [
                    'reward' => $this->settings['reward_name'],
                    'required' => $this->settings['invite_required'],
                    'stock' => $this->availableStock(),
                ]),
                $this->keyboard()
            );
            return;
        }

        if (!$this->ensureVerified($user, $chatId)) {
            return;
        }

        if ($text === $this->settings['button_claim_text'] || preg_match('/^1(?:\.|\s|$)/u', $text)) {
            $this->sendProgress($user, $chatId);
            return;
        }
        if ($text === $this->settings['button_link_text'] || preg_match('/^(?:2(?:\.|\s|$)|\/invite)/u', $text)) {
            $link = $this->inviteLink($user['invite_code']);
            $stock = $this->availableStock();
            $this->telegram->sendMessage(
                $chatId,
                "🔗 <b>你的专属邀请链接</b>\n\n{$link}\n\n🎁 当前剩余奖品：<b>{$stock}</b> 份\n\n好友通过此链接进入机器人并点击“开始”后，会自动计入邀请人数。",
                $this->keyboard()
            );
            return;
        }
        $this->telegram->sendMessage($chatId, '请选择下方的功能按钮。', $this->keyboard());
    }

    private function findOrCreateUser(array $from): array
    {
        $telegramId = (string)$from['id'];
        $stmt = $this->db->prepare('SELECT * FROM users WHERE telegram_user_id = ? LIMIT 1');
        $stmt->execute([$telegramId]);
        $user = $stmt->fetch();
        if ($user) {
            $this->db->prepare('UPDATE users SET telegram_username = ?, first_name = ?, is_bot = ?, last_active_at = NOW() WHERE id = ?')
                ->execute([$from['username'] ?? null, $from['first_name'] ?? null, !empty($from['is_bot']) ? 1 : 0, $user['id']]);
            return [$user, false];
        }
        for ($attempt = 0; $attempt < 5; $attempt++) {
            try {
                $code = random_invite_code();
                $this->db->prepare(
                    'INSERT INTO users (telegram_user_id, telegram_username, first_name, invite_code, is_bot) VALUES (?, ?, ?, ?, ?)'
                )->execute([$telegramId, $from['username'] ?? null, $from['first_name'] ?? null, $code, !empty($from['is_bot']) ? 1 : 0]);
                $id = (int)$this->db->lastInsertId();
                $stmt = $this->db->prepare('SELECT * FROM users WHERE id = ?');
                $stmt->execute([$id]);
                return [$stmt->fetch(), true];
            } catch (PDOException $exception) {
                if ($attempt === 4) throw $exception;
            }
        }
        throw new RuntimeException('无法生成邀请码');
    }

    private function ensureVerified(array $user, string $chatId): bool
    {
        if ((int)$this->settings['channel_verification_enabled'] !== 1) {
            $this->completeVerification($user);
            return true;
        }
        if ($this->isChannelMember((string)$user['telegram_user_id'])) {
            $this->completeVerification($user);
            return true;
        }
        $this->promptVerification($chatId);
        return false;
    }

    private function handleVerificationCallback(array $callback, array $user): void
    {
        $callbackId = (string)($callback['id'] ?? '');
        $chatId = (string)($callback['message']['chat']['id'] ?? $user['telegram_user_id']);
        try {
            if (!$this->isChannelMember((string)$user['telegram_user_id'])) {
                $this->telegram->call('answerCallbackQuery', [
                    'callback_query_id' => $callbackId,
                    'text' => '尚未检测到你加入频道，请加入后再验证。',
                    'show_alert' => true,
                ]);
                return;
            }
            $this->completeVerification($user);
            $this->telegram->call('answerCallbackQuery', [
                'callback_query_id' => $callbackId,
                'text' => '验证成功，邀请资格已解锁。',
                'show_alert' => false,
            ]);
            $this->telegram->sendMessage(
                $chatId,
                fill_template($this->settings['welcome_message'], [
                    'reward' => $this->settings['reward_name'],
                    'required' => $this->settings['invite_required'],
                    'stock' => $this->availableStock(),
                ]),
                $this->keyboard()
            );
        } catch (Throwable $exception) {
            $this->telegram->call('answerCallbackQuery', [
                'callback_query_id' => $callbackId,
                'text' => '验证暂时失败：' . mb_substr($exception->getMessage(), 0, 120),
                'show_alert' => true,
            ]);
        }
    }

    private function completeVerification(array $user): void
    {
        $this->db->prepare('UPDATE users SET verified_at = NOW() WHERE id = ?')->execute([$user['id']]);
        $pendingCode = trim((string)($user['pending_referral_code'] ?? ''));
        if ($pendingCode !== '' && empty($user['referred_by_user_id'])) {
            $this->recordReferral($user, $pendingCode);
        }
        $this->db->prepare('UPDATE users SET pending_referral_code = NULL WHERE id = ?')->execute([$user['id']]);
    }

    private function isChannelMember(string $telegramUserId): bool
    {
        if ((int)$this->settings['channel_verification_enabled'] !== 1) {
            return true;
        }
        $channelId = trim((string)($this->settings['required_channel_id'] ?? ''));
        if ($channelId === '') {
            throw new RuntimeException('管理员尚未配置验证频道');
        }
        $member = $this->telegram->call('getChatMember', [
            'chat_id' => $channelId,
            'user_id' => $telegramUserId,
        ]);
        $status = (string)($member['status'] ?? '');
        return in_array($status, ['creator', 'administrator', 'member'], true)
            || ($status === 'restricted' && !empty($member['is_member']));
    }

    private function promptVerification(string $chatId): void
    {
        $channelId = trim((string)($this->settings['required_channel_id'] ?? ''));
        $channelUrl = trim((string)($this->settings['required_channel_url'] ?? ''));
        if ($channelUrl === '' && str_starts_with($channelId, '@')) {
            $channelUrl = 'https://t.me/' . ltrim($channelId, '@');
        }
        $buttons = [];
        if (filter_var($channelUrl, FILTER_VALIDATE_URL)) {
            $buttons[] = [[
                'text' => $this->settings['join_button_text'],
                'url' => $channelUrl,
            ]];
        }
        $buttons[] = [[
            'text' => $this->settings['verify_button_text'],
            'callback_data' => 'verify_channel',
        ]];
        $this->telegram->sendMessage(
            $chatId,
            $this->settings['verification_message'],
            ['inline_keyboard' => $buttons]
        );
    }

    private function recordReferral(array $invitee, string $payload): void
    {
        $code = strtoupper(trim(preg_replace('/^ref_/i', '', $payload) ?? ''));
        if ($code === '' || hash_equals($invitee['invite_code'], $code)) return;
        $stmt = $this->db->prepare('SELECT * FROM users WHERE invite_code = ? LIMIT 1');
        $stmt->execute([$code]);
        $inviter = $stmt->fetch();
        if (!$inviter || (int)$inviter['id'] === (int)$invitee['id']) return;

        $this->db->beginTransaction();
        try {
            $stmt = $this->db->prepare('INSERT IGNORE INTO referrals (inviter_user_id, invitee_user_id) VALUES (?, ?)');
            $stmt->execute([$inviter['id'], $invitee['id']]);
            if ($stmt->rowCount() === 0) {
                $this->db->rollBack();
                return;
            }
            $this->db->prepare('UPDATE users SET referred_by_user_id = ? WHERE id = ? AND referred_by_user_id IS NULL')
                ->execute([$inviter['id'], $invitee['id']]);
            $this->db->prepare('UPDATE users SET referral_count = referral_count + 1 WHERE id = ?')
                ->execute([$inviter['id']]);
            $stmt = $this->db->prepare('SELECT * FROM users WHERE id = ? FOR UPDATE');
            $stmt->execute([$inviter['id']]);
            $inviter = $stmt->fetch();
            $required = max(1, (int)$this->settings['invite_required']);
            $qualified = (int)$inviter['referral_count'] % $required === 0;
            $rewardId = null;
            if ($qualified) {
                $cycle = intdiv((int)$inviter['referral_count'], $required);
                $this->db->prepare('INSERT IGNORE INTO rewards (user_id, cycle_no) VALUES (?, ?)')
                    ->execute([$inviter['id'], $cycle]);
                $stmt = $this->db->prepare('SELECT id FROM rewards WHERE user_id = ? AND cycle_no = ?');
                $stmt->execute([$inviter['id'], $cycle]);
                $rewardId = (int)$stmt->fetchColumn();
            }
            $this->db->commit();

            if ($qualified && $rewardId) {
                $message = fill_template($this->settings['qualified_message'], [
                    'count' => $inviter['referral_count'], 'reward' => $this->settings['reward_name'],
                    'required' => $required, 'stock' => $this->availableStock(),
                ]);
                $this->telegram->sendMessage($inviter['telegram_user_id'], $message, $this->keyboard());
                if ((int)$this->settings['auto_send_enabled'] === 1) {
                    $this->autoSendReward($rewardId, $inviter);
                }
            } else {
                $remaining = $required - ((int)$inviter['referral_count'] % $required);
                $message = fill_template($this->settings['progress_message'], [
                    'count' => $inviter['referral_count'], 'remaining' => $remaining,
                    'reward' => $this->settings['reward_name'], 'required' => $required,
                    'stock' => $this->availableStock(),
                ]);
                $this->telegram->sendMessage($inviter['telegram_user_id'], $message, $this->keyboard());
            }
        } catch (Throwable $exception) {
            if ($this->db->inTransaction()) $this->db->rollBack();
            throw $exception;
        }
    }

    private function autoSendReward(int $rewardId, array $user): void
    {
        $this->db->beginTransaction();
        try {
            $stmt = $this->db->query("SELECT * FROM reward_inventory WHERE status = 'available' ORDER BY id ASC LIMIT 1 FOR UPDATE");
            $inventory = $stmt->fetch();
            if (!$inventory) {
                $this->db->commit();
                return;
            }
            $this->db->prepare("UPDATE reward_inventory SET status = 'assigned', reward_id = ?, assigned_at = NOW() WHERE id = ?")
                ->execute([$rewardId, $inventory['id']]);
            $this->db->prepare('UPDATE rewards SET prize_content_encrypted = ? WHERE id = ?')
                ->execute([$inventory['content_encrypted'], $rewardId]);
            $this->db->commit();
            $content = Crypto::decrypt($inventory['content_encrypted'], $this->config['encryption_key']);
            $this->deliverReward($rewardId, $user['telegram_user_id'], $content);
        } catch (Throwable $exception) {
            if ($this->db->inTransaction()) $this->db->rollBack();
            $this->db->prepare("UPDATE rewards SET status = 'failed', error_message = ? WHERE id = ?")
                ->execute([mb_substr($exception->getMessage(), 0, 500), $rewardId]);
        }
    }

    public function deliverReward(int $rewardId, int|string $telegramUserId, string $content): void
    {
        $message = fill_template($this->settings['reward_message'], [
            'reward' => $this->settings['reward_name'], 'content' => $content,
        ]);
        $this->telegram->sendMessage($telegramUserId, $message);
        $encrypted = Crypto::encrypt($content, $this->config['encryption_key']);
        $this->db->prepare("UPDATE rewards SET status = 'sent', prize_content_encrypted = ?, error_message = NULL, sent_at = NOW() WHERE id = ?")
            ->execute([$encrypted, $rewardId]);
    }

    private function sendProgress(array $user, string $chatId): void
    {
        $stmt = $this->db->prepare('SELECT referral_count FROM users WHERE id = ?');
        $stmt->execute([$user['id']]);
        $count = (int)$stmt->fetchColumn();
        $required = max(1, (int)$this->settings['invite_required']);
        $remaining = $required - ($count % $required);
        $earned = intdiv($count, $required);
        $link = $this->inviteLink($user['invite_code']);
        $stock = $this->availableStock();
        $this->telegram->sendMessage(
            $chatId,
            "🎫 <b>你的专属邀请码</b>\n<code>{$user['invite_code']}</code>\n\n👥 已邀请：<b>{$count}</b> 人\n🏆 累计达标：<b>{$earned}</b> 次\n⏳ 下次奖励还差：<b>{$remaining}</b> 人\n🎁 当前剩余奖品：<b>{$stock}</b> 份\n\n专属链接：\n{$link}",
            $this->keyboard()
        );
    }

    private function inviteLink(string $code): string
    {
        $username = ltrim((string)$this->settings['bot_username'], '@');
        return $username ? 'https://t.me/' . $username . '?start=ref_' . $code : '邀请码：' . $code;
    }

    private function availableStock(): int
    {
        return (int)$this->db->query("SELECT COUNT(*) FROM reward_inventory WHERE status = 'available'")->fetchColumn();
    }
}
