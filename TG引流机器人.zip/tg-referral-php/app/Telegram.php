<?php
declare(strict_types=1);

final class Telegram
{
    public function __construct(private readonly string $token)
    {
    }

    public function call(string $method, array $payload = []): array
    {
        $url = 'https://api.telegram.org/bot' . $this->token . '/' . $method;
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_TIMEOUT => 20,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
            CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        ]);
        $body = curl_exec($ch);
        $error = curl_error($ch);
        $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($body === false) {
            throw new RuntimeException('无法连接 Telegram：' . $error);
        }
        $response = json_decode($body, true);
        if ($status >= 400 || !is_array($response) || empty($response['ok'])) {
            throw new RuntimeException($response['description'] ?? ('Telegram 请求失败，HTTP ' . $status));
        }
        return $response['result'] ?? [];
    }

    public function sendMessage(int|string $chatId, string $text, ?array $keyboard = null): array
    {
        $payload = [
            'chat_id' => $chatId,
            'text' => $text,
            'parse_mode' => 'HTML',
            'disable_web_page_preview' => true,
        ];
        if ($keyboard !== null) {
            $payload['reply_markup'] = $keyboard;
        }
        return $this->call('sendMessage', $payload);
    }
}
