<?php
return [
    'app_url' => 'https://example.com',
    'timezone' => 'Asia/Shanghai',
    'session_secret' => 'replace-with-random-secret',
    'encryption_key' => 'replace-with-random-encryption-key',
    'db' => [
        'host' => '127.0.0.1',
        'port' => 3306,
        'name' => 'tg_referral',
        'user' => 'tg_referral',
        'pass' => 'your-database-password',
        'charset' => 'utf8mb4',
    ],
];
