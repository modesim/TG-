<?php
declare(strict_types=1);

function app_config(?string $key = null, mixed $default = null): mixed
{
    $config = $GLOBALS['app_config'] ?? [];
    return $key === null ? $config : ($config[$key] ?? $default);
}

function db(): PDO
{
    return $GLOBALS['pdo'];
}

function e(mixed $value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function redirect(string $url): never
{
    header('Location: ' . $url);
    exit;
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf(): void
{
    $token = $_POST['csrf_token'] ?? '';
    if (!is_string($token) || !hash_equals($_SESSION['csrf_token'] ?? '', $token)) {
        http_response_code(419);
        exit('页面已过期，请返回后刷新重试。');
    }
}

function flash(string $type, string $message): void
{
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function take_flash(): ?array
{
    $flash = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $flash;
}

function get_settings(): array
{
    $row = db()->query('SELECT * FROM settings WHERE id = 1')->fetch();
    if (!$row) {
        throw new RuntimeException('系统设置尚未初始化');
    }
    return $row;
}

function fill_template(string $template, array $variables): string
{
    $replace = [];
    foreach ($variables as $key => $value) {
        $replace['{' . $key . '}'] = htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
    return strtr($template, $replace);
}

function telegram_name(array $row): string
{
    if (!empty($row['first_name'])) return $row['first_name'];
    if (!empty($row['telegram_username'])) return '@' . $row['telegram_username'];
    return 'TG ' . $row['telegram_user_id'];
}

function random_invite_code(int $length = 8): string
{
    $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    $code = '';
    for ($i = 0; $i < $length; $i++) {
        $code .= $alphabet[random_int(0, strlen($alphabet) - 1)];
    }
    return $code;
}
