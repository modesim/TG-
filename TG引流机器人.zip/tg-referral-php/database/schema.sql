CREATE TABLE IF NOT EXISTS admins (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  username VARCHAR(80) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_login_at DATETIME NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_admins_username (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS settings (
  id TINYINT UNSIGNED NOT NULL DEFAULT 1,
  bot_token_encrypted TEXT NULL,
  bot_username VARCHAR(120) NULL,
  reward_name VARCHAR(120) NOT NULL DEFAULT '捷克 eSIM',
  invite_required INT UNSIGNED NOT NULL DEFAULT 3,
  auto_send_enabled TINYINT(1) NOT NULL DEFAULT 1,
  channel_verification_enabled TINYINT(1) NOT NULL DEFAULT 1,
  required_channel_id VARCHAR(160) NULL,
  required_channel_url VARCHAR(255) NULL,
  join_button_text VARCHAR(120) NOT NULL DEFAULT '加入指定频道',
  verify_button_text VARCHAR(120) NOT NULL DEFAULT '✅ 我已加入，点击验证',
  verification_message TEXT NOT NULL,
  welcome_message TEXT NOT NULL,
  button_claim_text VARCHAR(120) NOT NULL DEFAULT '1. 领取捷克 eSIM',
  button_link_text VARCHAR(120) NOT NULL DEFAULT '2. 查看邀请链接',
  progress_message TEXT NOT NULL,
  qualified_message TEXT NOT NULL,
  reward_message TEXT NOT NULL,
  webhook_secret VARCHAR(128) NOT NULL,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS users (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  telegram_user_id BIGINT NOT NULL,
  telegram_username VARCHAR(120) NULL,
  first_name VARCHAR(160) NULL,
  invite_code VARCHAR(20) NOT NULL,
  referred_by_user_id BIGINT UNSIGNED NULL,
  pending_referral_code VARCHAR(20) NULL,
  verified_at DATETIME NULL,
  is_bot TINYINT(1) NOT NULL DEFAULT 0,
  referral_count INT UNSIGNED NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_active_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_users_telegram_user_id (telegram_user_id),
  UNIQUE KEY uq_users_invite_code (invite_code),
  KEY idx_users_referred_by (referred_by_user_id),
  KEY idx_users_last_active (last_active_at),
  CONSTRAINT fk_users_referrer FOREIGN KEY (referred_by_user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS referrals (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  inviter_user_id BIGINT UNSIGNED NOT NULL,
  invitee_user_id BIGINT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_referrals_invitee (invitee_user_id),
  KEY idx_referrals_inviter (inviter_user_id),
  CONSTRAINT fk_referrals_inviter FOREIGN KEY (inviter_user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_referrals_invitee FOREIGN KEY (invitee_user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS rewards (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id BIGINT UNSIGNED NOT NULL,
  cycle_no INT UNSIGNED NOT NULL,
  status ENUM('pending','sent','failed') NOT NULL DEFAULT 'pending',
  prize_content_encrypted TEXT NULL,
  error_message VARCHAR(500) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  sent_at DATETIME NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_rewards_user_cycle (user_id, cycle_no),
  KEY idx_rewards_status_created (status, created_at),
  CONSTRAINT fk_rewards_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS reward_inventory (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  content_encrypted TEXT NOT NULL,
  content_preview VARCHAR(120) NOT NULL,
  status ENUM('available','assigned') NOT NULL DEFAULT 'available',
  reward_id BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  assigned_at DATETIME NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_inventory_reward (reward_id),
  KEY idx_inventory_status_id (status, id),
  CONSTRAINT fk_inventory_reward FOREIGN KEY (reward_id) REFERENCES rewards(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bot_updates (
  update_id BIGINT NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (update_id),
  KEY idx_bot_updates_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
