-- 仅供已安装旧版本升级使用。新安装不需要执行此文件。
ALTER TABLE settings
  ADD COLUMN channel_verification_enabled TINYINT(1) NOT NULL DEFAULT 1 AFTER auto_send_enabled,
  ADD COLUMN required_channel_id VARCHAR(160) NULL AFTER channel_verification_enabled,
  ADD COLUMN required_channel_url VARCHAR(255) NULL AFTER required_channel_id,
  ADD COLUMN join_button_text VARCHAR(120) NOT NULL DEFAULT '加入指定频道' AFTER required_channel_url,
  ADD COLUMN verify_button_text VARCHAR(120) NOT NULL DEFAULT '✅ 我已加入，点击验证' AFTER join_button_text,
  ADD COLUMN verification_message TEXT NULL AFTER verify_button_text;

UPDATE settings
SET verification_message = '领取邀请码前，请先加入指定频道，然后点击“验证加入”。'
WHERE id = 1 AND (verification_message IS NULL OR verification_message = '');

ALTER TABLE settings
  MODIFY COLUMN verification_message TEXT NOT NULL;

ALTER TABLE users
  ADD COLUMN pending_referral_code VARCHAR(20) NULL AFTER referred_by_user_id,
  ADD COLUMN verified_at DATETIME NULL AFTER pending_referral_code,
  ADD COLUMN is_bot TINYINT(1) NOT NULL DEFAULT 0 AFTER verified_at;

-- 已有用户会在下一次使用机器人时重新验证频道成员身份。
