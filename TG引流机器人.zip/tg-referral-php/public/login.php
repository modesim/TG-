<?php
declare(strict_types=1);
require_once dirname(__DIR__) . '/app/bootstrap.php';
if (Auth::check()) redirect('index.php');
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    if (Auth::attempt(trim((string)($_POST['username'] ?? '')), (string)($_POST['password'] ?? ''))) {
        redirect('index.php');
    }
    $error = '管理员账号或密码不正确';
}
?>
<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>管理员登录 · TG 引流中心</title><link rel="icon" href="favicon.svg" type="image/svg+xml"><link rel="stylesheet" href="assets/app.css"></head>
<body class="login-page"><main class="login-shell"><section class="login-card"><div class="brand-icon">✦</div><span class="eyebrow">管理员专属入口</span><h1>TG 引流中心</h1><p>配置机器人、查看邀请进度并自动发放 eSIM 奖励。</p><?php if (isset($_GET['installed'])): ?><div class="alert success">安装成功，请使用刚创建的管理员账号登录。</div><?php endif; ?><?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?><form method="post"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><label>管理员账号<input name="username" autocomplete="username" required autofocus></label><label>管理员密码<input name="password" type="password" autocomplete="current-password" required></label><button class="btn primary wide" type="submit">安全登录</button></form><small>后台与机器人密钥均在服务器端安全处理</small></section></main></body></html>
