<?php
declare(strict_types=1);
require_once dirname(__DIR__) . '/app/bootstrap.php';
Auth::requireLogin();

$pdo = db();
$config = app_config();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = (string)($_POST['action'] ?? '');
    try {
        if ($action === 'save_settings') {
            $settings = get_settings();
            $inviteRequired = max(1, min(1000, (int)($_POST['invite_required'] ?? 3)));
            $rewardName = trim((string)($_POST['reward_name'] ?? '捷克 eSIM'));
            $claimText = trim((string)($_POST['button_claim_text'] ?? '1. 领取捷克 eSIM'));
            $linkText = trim((string)($_POST['button_link_text'] ?? '2. 查看邀请链接'));
            if ($rewardName === '' || $claimText === '' || $linkText === '') {
                throw new RuntimeException('奖品名称和机器人按钮不能为空');
            }
            $encryptedToken = $settings['bot_token_encrypted'];
            $newToken = trim((string)($_POST['bot_token'] ?? ''));
            if ($newToken !== '') {
                $encryptedToken = Crypto::encrypt($newToken, $config['encryption_key']);
            }
            $stmt = $pdo->prepare(
                'UPDATE settings SET bot_token_encrypted = ?, bot_username = ?, reward_name = ?,
                 invite_required = ?, auto_send_enabled = ?, welcome_message = ?, button_claim_text = ?,
                 button_link_text = ?, progress_message = ?, qualified_message = ?, reward_message = ? WHERE id = 1'
            );
            $stmt->execute([
                $encryptedToken,
                ltrim(trim((string)($_POST['bot_username'] ?? '')), '@'),
                $rewardName,
                $inviteRequired,
                isset($_POST['auto_send_enabled']) ? 1 : 0,
                trim((string)($_POST['welcome_message'] ?? '')),
                $claimText,
                $linkText,
                trim((string)($_POST['progress_message'] ?? '')),
                trim((string)($_POST['qualified_message'] ?? '')),
                trim((string)($_POST['reward_message'] ?? '')),
            ]);
            flash('success', '机器人与奖励规则已保存');
            redirect('index.php?tab=settings');
        }

        if ($action === 'save_verification') {
            $enabled = isset($_POST['channel_verification_enabled']) ? 1 : 0;
            $channelId = trim((string)($_POST['required_channel_id'] ?? ''));
            $channelUrl = trim((string)($_POST['required_channel_url'] ?? ''));
            $joinText = trim((string)($_POST['join_button_text'] ?? '加入指定频道'));
            $verifyText = trim((string)($_POST['verify_button_text'] ?? '✅ 我已加入，点击验证'));
            $message = trim((string)($_POST['verification_message'] ?? ''));
            if ($enabled && $channelId === '') {
                throw new RuntimeException('开启频道验证时必须填写频道 ID');
            }
            if ($channelUrl !== '' && !filter_var($channelUrl, FILTER_VALIDATE_URL)) {
                throw new RuntimeException('频道链接必须是完整的 https:// 地址');
            }
            if ($joinText === '' || $verifyText === '' || $message === '') {
                throw new RuntimeException('验证按钮和提示文案不能为空');
            }
            $pdo->prepare(
                'UPDATE settings SET channel_verification_enabled = ?, required_channel_id = ?,
                 required_channel_url = ?, join_button_text = ?, verify_button_text = ?,
                 verification_message = ? WHERE id = 1'
            )->execute([$enabled, $channelId ?: null, $channelUrl ?: null, $joinText, $verifyText, $message]);
            flash('success', '频道验证规则已保存');
            redirect('index.php?tab=settings');
        }

        if ($action === 'test_channel') {
            $current = get_settings();
            if (empty($current['required_channel_id'])) throw new RuntimeException('请先保存频道 ID');
            $service = new BotService();
            $me = $service->telegram()->call('getMe');
            $admins = $service->telegram()->call('getChatAdministrators', ['chat_id' => $current['required_channel_id']]);
            $isAdmin = false;
            foreach ($admins as $admin) {
                if ((string)($admin['user']['id'] ?? '') === (string)($me['id'] ?? '')) {
                    $isAdmin = true;
                    break;
                }
            }
            if (!$isAdmin) throw new RuntimeException('机器人尚未成为该频道管理员');
            flash('success', '频道连接正常，机器人已具备管理员身份');
            redirect('index.php?tab=settings');
        }

        if ($action === 'test_bot') {
            $bot = (new BotService())->telegram()->call('getMe');
            $username = (string)($bot['username'] ?? '');
            if ($username !== '') {
                $pdo->prepare('UPDATE settings SET bot_username = ? WHERE id = 1')->execute([$username]);
            }
            flash('success', '连接成功：@' . $username);
            redirect('index.php?tab=settings');
        }

        if ($action === 'set_webhook') {
            $settings = get_settings();
            $service = new BotService();
            $bot = $service->telegram()->call('getMe');
            if (!empty($bot['username'])) {
                $pdo->prepare('UPDATE settings SET bot_username = ? WHERE id = 1')->execute([$bot['username']]);
            }
            $webhookUrl = rtrim($config['app_url'], '/') . '/webhook.php';
            $service->telegram()->call('setWebhook', [
                'url' => $webhookUrl,
                'secret_token' => $settings['webhook_secret'],
                'allowed_updates' => ['message', 'callback_query'],
                'drop_pending_updates' => false,
            ]);
            $service->telegram()->call('setMyCommands', ['commands' => [
                ['command' => 'start', 'description' => '开始 / 查看活动'],
                ['command' => 'invite', 'description' => '查看邀请链接'],
            ]]);
            flash('success', 'Webhook 已设置为 ' . $webhookUrl);
            redirect('index.php?tab=settings');
        }

        if ($action === 'add_inventory') {
            $raw = trim((string)($_POST['inventory_content'] ?? ''));
            $items = array_values(array_filter(array_map('trim', preg_split('/\R/u', $raw) ?: [])));
            if (!$items) throw new RuntimeException('请至少输入一条奖品内容');
            if (count($items) > 500) throw new RuntimeException('每次最多导入 500 条');
            $stmt = $pdo->prepare('INSERT INTO reward_inventory (content_encrypted, content_preview) VALUES (?, ?)');
            $pdo->beginTransaction();
            foreach ($items as $item) {
                $stmt->execute([
                    Crypto::encrypt($item, $config['encryption_key']),
                    Crypto::preview($item),
                ]);
            }
            $pdo->commit();
            flash('success', '已导入 ' . count($items) . ' 条奖励库存');
            redirect('index.php?tab=inventory');
        }

        if ($action === 'delete_inventory') {
            $stmt = $pdo->prepare("DELETE FROM reward_inventory WHERE id = ? AND status = 'available'");
            $stmt->execute([(int)($_POST['inventory_id'] ?? 0)]);
            flash('success', $stmt->rowCount() ? '库存已删除' : '该库存已被分配，无法删除');
            redirect('index.php?tab=inventory');
        }

        if ($action === 'send_reward') {
            $rewardId = (int)($_POST['reward_id'] ?? 0);
            $stmt = $pdo->prepare(
                'SELECT r.*, u.telegram_user_id FROM rewards r JOIN users u ON u.id = r.user_id WHERE r.id = ? LIMIT 1'
            );
            $stmt->execute([$rewardId]);
            $reward = $stmt->fetch();
            if (!$reward) throw new RuntimeException('奖励记录不存在');
            if ($reward['status'] === 'sent') throw new RuntimeException('该奖励已经发送');
            $content = trim((string)($_POST['prize_content'] ?? ''));
            if ($content === '' && !empty($reward['prize_content_encrypted'])) {
                $content = Crypto::decrypt($reward['prize_content_encrypted'], $config['encryption_key']);
            }
            if ($content === '') throw new RuntimeException('请输入奖品内容，或先导入库存');
            (new BotService())->deliverReward($rewardId, $reward['telegram_user_id'], $content);
            flash('success', '奖品已通过机器人发送');
            redirect('index.php?tab=rewards');
        }

        if ($action === 'change_password') {
            $stmt = $pdo->prepare('SELECT password_hash FROM admins WHERE id = ?');
            $stmt->execute([$_SESSION['admin_id']]);
            $hash = (string)$stmt->fetchColumn();
            $current = (string)($_POST['current_password'] ?? '');
            $new = (string)($_POST['new_password'] ?? '');
            if (!password_verify($current, $hash)) throw new RuntimeException('当前密码不正确');
            if (mb_strlen($new) < 10) throw new RuntimeException('新密码至少 10 位');
            $pdo->prepare('UPDATE admins SET password_hash = ? WHERE id = ?')
                ->execute([password_hash($new, PASSWORD_DEFAULT), $_SESSION['admin_id']]);
            flash('success', '管理员密码已更新');
            redirect('index.php?tab=security');
        }
    } catch (Throwable $exception) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        flash('error', $exception->getMessage());
        redirect('index.php?tab=' . urlencode((string)($_GET['tab'] ?? $_POST['return_tab'] ?? 'overview')));
    }
}

$tab = (string)($_GET['tab'] ?? 'overview');
$allowedTabs = ['overview', 'users', 'rewards', 'inventory', 'settings', 'security'];
if (!in_array($tab, $allowedTabs, true)) $tab = 'overview';
$settings = get_settings();
$flash = take_flash();

$stats = [
    'users' => (int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn(),
    'referrals' => (int)$pdo->query('SELECT COUNT(*) FROM referrals')->fetchColumn(),
    'pending' => (int)$pdo->query("SELECT COUNT(*) FROM rewards WHERE status IN ('pending','failed')")->fetchColumn(),
    'sent' => (int)$pdo->query("SELECT COUNT(*) FROM rewards WHERE status = 'sent'")->fetchColumn(),
    'inventory' => (int)$pdo->query("SELECT COUNT(*) FROM reward_inventory WHERE status = 'available'")->fetchColumn(),
];
$users = $pdo->query('SELECT * FROM users ORDER BY created_at DESC LIMIT 200')->fetchAll();
$rewards = $pdo->query(
    "SELECT r.*, u.telegram_user_id, u.telegram_username, u.first_name, u.referral_count,
            i.content_preview
     FROM rewards r
     JOIN users u ON u.id = r.user_id
     LEFT JOIN reward_inventory i ON i.reward_id = r.id
     ORDER BY FIELD(r.status, 'pending', 'failed', 'sent'), r.created_at DESC LIMIT 200"
)->fetchAll();
$inventory = $pdo->query('SELECT id, content_preview, status, reward_id, created_at, assigned_at FROM reward_inventory ORDER BY id DESC LIMIT 300')->fetchAll();
$recentUsers = array_slice($users, 0, 6);

function active_nav(string $name, string $tab): string { return $name === $tab ? 'active' : ''; }
?>
<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <title>TG 引流中心</title><link rel="icon" href="favicon.svg" type="image/svg+xml"><link rel="stylesheet" href="assets/app.css">
</head>
<body class="admin-page">
<div class="admin-shell">
  <aside class="sidebar">
    <a class="sidebar-brand" href="index.php"><span class="brand-icon small">✦</span><span><strong>引流中心</strong><small>TG Referral Ops</small></span></a>
    <nav>
      <a class="<?= active_nav('overview', $tab) ?>" href="?tab=overview"><i>⌁</i>数据总览</a>
      <a class="<?= active_nav('users', $tab) ?>" href="?tab=users"><i>◎</i>用户与邀请</a>
      <a class="<?= active_nav('rewards', $tab) ?>" href="?tab=rewards"><i>◇</i>奖励发放<?php if ($stats['pending']): ?><b><?= $stats['pending'] ?></b><?php endif; ?></a>
      <a class="<?= active_nav('inventory', $tab) ?>" href="?tab=inventory"><i>▦</i>奖励库存</a>
      <a class="<?= active_nav('settings', $tab) ?>" href="?tab=settings"><i>⚙</i>机器人配置</a>
      <a class="<?= active_nav('security', $tab) ?>" href="?tab=security"><i>◆</i>账号安全</a>
    </nav>
    <div class="sidebar-footer"><div class="bot-state"><span class="dot <?= $settings['bot_token_encrypted'] ? 'online' : '' ?>"></span><div><strong><?= $settings['bot_token_encrypted'] ? '机器人已配置' : '等待配置' ?></strong><small><?= $settings['bot_username'] ? '@' . e($settings['bot_username']) : '尚未连接 Bot' ?></small></div></div><a class="logout-link" href="logout.php">退出登录</a></div>
  </aside>
  <main class="main-content">
    <header class="topbar"><button class="menu-button" type="button" data-menu>☰</button><div><p class="eyebrow">运营控制台</p><h1><?= ['overview'=>'邀请增长，一目了然','users'=>'用户与邀请','rewards'=>'奖励发放','inventory'=>'奖励库存','settings'=>'机器人配置','security'=>'账号安全'][$tab] ?></h1></div><div class="admin-badge">管</div></header>
    <?php if ($flash): ?><div class="alert <?= e($flash['type']) ?> dashboard-alert"><?= e($flash['message']) ?></div><?php endif; ?>

    <?php if ($tab === 'overview'): ?>
      <?php if (!$settings['bot_token_encrypted']): ?><section class="setup-banner"><div><span>!</span><div><strong>先完成机器人配置</strong><p>保存 Bot Token、测试连接，再启用 Webhook。</p></div></div><a class="btn primary" href="?tab=settings">开始配置</a></section><?php endif; ?>
      <?php if ($settings['channel_verification_enabled'] && !$settings['required_channel_id']): ?><section class="setup-banner"><div><span>!</span><div><strong>频道验证尚未完成</strong><p>请填写频道 ID，并确保机器人已经成为该频道管理员。</p></div></div><a class="btn primary" href="?tab=settings">配置频道</a></section><?php endif; ?>
      <section class="stat-grid">
        <article class="stat-card"><span class="stat-icon cyan">◎</span><div><p>机器人用户</p><strong><?= number_format($stats['users']) ?></strong></div></article>
        <article class="stat-card"><span class="stat-icon violet">↗</span><div><p>有效邀请</p><strong><?= number_format($stats['referrals']) ?></strong></div></article>
        <article class="stat-card"><span class="stat-icon orange">◇</span><div><p>待发奖励</p><strong><?= number_format($stats['pending']) ?></strong></div></article>
        <article class="stat-card"><span class="stat-icon green">✓</span><div><p>可用库存</p><strong><?= number_format($stats['inventory']) ?></strong></div></article>
      </section>
      <section class="overview-grid">
        <article class="panel campaign-card"><div class="panel-heading"><div><p class="eyebrow">当前活动</p><h2><?= e($settings['reward_name']) ?> 邀请奖励</h2></div><span class="status-pill"><i></i>运行中</span></div><div class="campaign-rule"><b><?= (int)$settings['invite_required'] ?></b><div><strong>位有效邀请 / 次</strong><p>每满 <?= (int)$settings['invite_required'] ?> 位已通过频道验证的新用户，自动创建一条奖励。</p></div></div><div class="rule-meta"><span>频道验证 <b><?= $settings['channel_verification_enabled'] ? '已开启' : '未开启' ?></b></span><span>自动发放 <b><?= $settings['auto_send_enabled'] ? '已开启' : '未开启' ?></b></span><span>累计已发 <b><?= $stats['sent'] ?></b></span></div></article>
        <article class="panel flow-card"><div class="panel-heading"><div><p class="eyebrow">用户路径</p><h2>机器人自动流程</h2></div><span class="ghost-icon">✦</span></div><ol><li><i>1</i><div><strong>加入频道并验证</strong><p>验证通过后才解锁专属邀请码</p></div></li><li><i>2</i><div><strong><?= e($settings['button_link_text']) ?></strong><p>受邀人验证成功后才计为有效邀请</p></div></li><li><i>3</i><div><strong>达标自动发奖</strong><p>从库存取一条内容并私发</p></div></li></ol></article>
      </section>
      <section class="panel"><div class="panel-heading"><div><p class="eyebrow">最新动态</p><h2>最近加入的用户</h2></div><span class="count-chip">共 <?= $stats['users'] ?> 人</span></div><?php if ($recentUsers): ?><div class="activity-list"><?php foreach ($recentUsers as $user): ?><div class="activity-row"><span class="avatar"><?= e(mb_substr(telegram_name($user), 0, 1)) ?></span><div><strong><?= e(telegram_name($user)) ?></strong><small>邀请码 <?= e($user['invite_code']) ?></small></div><b><?= (int)$user['referral_count'] ?> 位邀请</b><time><?= e(date('m-d H:i', strtotime($user['created_at']))) ?></time></div><?php endforeach; ?></div><?php else: ?><div class="empty-state"><span>◎</span><strong>还没有用户</strong><p>启用机器人后，新用户会显示在这里。</p></div><?php endif; ?></section>
    <?php endif; ?>

    <?php if ($tab === 'users'): ?>
      <section class="panel table-panel"><div class="panel-heading"><div><p class="eyebrow">用户明细</p><h2>机器人用户与邀请</h2></div><span class="count-chip"><?= count($users) ?> 条</span></div><?php if ($users): ?><div class="table-wrap"><table><thead><tr><th>用户</th><th>TG ID</th><th>邀请码</th><th>邀请人数</th><th>加入时间</th></tr></thead><tbody><?php foreach ($users as $user): ?><tr><td><div class="table-user"><span><?= e(mb_substr(telegram_name($user), 0, 1)) ?></span><div><strong><?= e(telegram_name($user)) ?></strong><small><?= $user['telegram_username'] ? '@' . e($user['telegram_username']) : '未设置用户名' ?></small></div></div></td><td class="mono"><?= e($user['telegram_user_id']) ?></td><td><code><?= e($user['invite_code']) ?></code></td><td><b><?= (int)$user['referral_count'] ?></b> / <?= (int)$settings['invite_required'] ?></td><td><?= e(date('Y-m-d H:i', strtotime($user['created_at']))) ?></td></tr><?php endforeach; ?></tbody></table></div><?php else: ?><div class="empty-state"><span>◎</span><strong>暂无用户数据</strong><p>用户点击机器人“开始”后会自动出现。</p></div><?php endif; ?></section>
    <?php endif; ?>

    <?php if ($tab === 'rewards'): ?>
      <section class="panel table-panel"><div class="panel-heading"><div><p class="eyebrow">奖励队列</p><h2>发放 <?= e($settings['reward_name']) ?></h2></div><span class="count-chip orange"><?= $stats['pending'] ?> 待处理</span></div><?php if ($rewards): ?><div class="table-wrap"><table><thead><tr><th>用户</th><th>轮次</th><th>奖品</th><th>状态</th><th>生成时间</th><th></th></tr></thead><tbody><?php foreach ($rewards as $reward): ?><tr><td><div class="table-user"><span><?= e(mb_substr(telegram_name($reward), 0, 1)) ?></span><div><strong><?= e(telegram_name($reward)) ?></strong><small><?= (int)$reward['referral_count'] ?> 位有效邀请</small></div></div></td><td>第 <?= (int)$reward['cycle_no'] ?> 次</td><td><?= $reward['content_preview'] ? e($reward['content_preview']) : '未分配' ?></td><td><span class="status <?= e($reward['status']) ?>"><?= ['pending'=>'待发送','failed'=>'发送失败','sent'=>'已发送'][$reward['status']] ?></span><?php if ($reward['error_message']): ?><small class="error-note"><?= e($reward['error_message']) ?></small><?php endif; ?></td><td><?= e(date('m-d H:i', strtotime($reward['created_at']))) ?></td><td><?php if ($reward['status'] === 'sent'): ?><span class="done">✓ 完成</span><?php else: ?><button class="btn small primary" type="button" data-reward-id="<?= (int)$reward['id'] ?>" data-assigned="<?= $reward['prize_content_encrypted'] ? '1' : '0' ?>" data-reward-user="<?= e(telegram_name($reward)) ?>"><?= $reward['prize_content_encrypted'] ? '重试发送' : '手动发奖' ?></button><?php endif; ?></td></tr><?php endforeach; ?></tbody></table></div><?php else: ?><div class="empty-state"><span>◇</span><strong>暂无奖励记录</strong><p>用户每邀请 <?= (int)$settings['invite_required'] ?> 人，系统会自动创建奖励。</p></div><?php endif; ?></section>
    <?php endif; ?>

    <?php if ($tab === 'inventory'): ?>
      <section class="two-column"><form class="panel form-panel" method="post"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="add_inventory"><input type="hidden" name="return_tab" value="inventory"><div class="panel-heading"><div><p class="eyebrow">批量入库</p><h2>添加 eSIM / 兑换码</h2></div><span class="stat-icon green">+</span></div><label>每行一条奖品内容<textarea name="inventory_content" rows="12" placeholder="LPA:1$...&#10;激活码：XXXX-XXXX&#10;或完整领奖说明" required></textarea><small>内容将使用 AES-256-GCM 加密保存；每次最多 500 条。</small></label><button class="btn primary" type="submit">导入库存</button></form><article class="panel inventory-summary"><p class="eyebrow">库存状态</p><h2><?= $stats['inventory'] ?> 条可自动发放</h2><div class="big-meter"><span style="width:<?= min(100, $stats['inventory']) ?>%"></span></div><p>开启自动发放后，用户达标时会按入库顺序取一条库存并私发。库存不足时保留待发记录。</p></article></section>
      <section class="panel table-panel"><div class="panel-heading"><div><p class="eyebrow">库存明细</p><h2>最近 300 条</h2></div></div><?php if ($inventory): ?><div class="table-wrap"><table><thead><tr><th>ID</th><th>内容预览</th><th>状态</th><th>入库时间</th><th></th></tr></thead><tbody><?php foreach ($inventory as $item): ?><tr><td class="mono">#<?= (int)$item['id'] ?></td><td><code><?= e($item['content_preview']) ?></code></td><td><span class="status <?= $item['status'] === 'available' ? 'pending' : 'sent' ?>"><?= $item['status'] === 'available' ? '可用' : '已分配' ?></span></td><td><?= e(date('Y-m-d H:i', strtotime($item['created_at']))) ?></td><td><?php if ($item['status'] === 'available'): ?><form method="post" onsubmit="return confirm('确定删除这条库存吗？')"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="delete_inventory"><input type="hidden" name="inventory_id" value="<?= (int)$item['id'] ?>"><input type="hidden" name="return_tab" value="inventory"><button class="btn small danger" type="submit">删除</button></form><?php endif; ?></td></tr><?php endforeach; ?></tbody></table></div><?php else: ?><div class="empty-state"><span>▦</span><strong>库存为空</strong><p>在上方每行输入一条奖品内容后导入。</p></div><?php endif; ?></section>
    <?php endif; ?>

    <?php if ($tab === 'settings'): ?>
      <form class="panel form-panel verification-panel" method="post">
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="return_tab" value="settings">
        <div class="panel-heading"><div><p class="eyebrow">防刷验证</p><h2>加入频道后才计为有效邀请</h2></div><span class="stat-icon orange">盾</span></div>
        <label class="switch-row"><span><strong>启用频道成员验证</strong><small>未通过验证的账号不能查看专属邀请码，也不会给邀请人增加人数。</small></span><input name="channel_verification_enabled" type="checkbox" value="1" <?= $settings['channel_verification_enabled'] ? 'checked' : '' ?>></label>
        <div class="form-grid"><label>频道 ID<input name="required_channel_id" value="<?= e($settings['required_channel_id']) ?>" placeholder="公开频道填 @channel，私有频道填 -100..."><small>机器人必须是该频道管理员。</small></label><label>频道加入链接<input name="required_channel_url" type="url" value="<?= e($settings['required_channel_url']) ?>" placeholder="https://t.me/channel 或私有邀请链接"></label></div>
        <div class="form-grid"><label>加入频道按钮<input name="join_button_text" value="<?= e($settings['join_button_text']) ?>" required></label><label>验证按钮<input name="verify_button_text" value="<?= e($settings['verify_button_text']) ?>" required></label></div>
        <label>验证提示文案<textarea name="verification_message" rows="4" required><?= e($settings['verification_message']) ?></textarea></label>
        <div class="dialog-actions"><button class="btn outline" type="submit" name="action" value="test_channel" <?= !$settings['bot_token_encrypted'] || !$settings['required_channel_id'] ? 'disabled' : '' ?>>检查机器人频道权限</button><button class="btn primary" type="submit" name="action" value="save_verification">保存验证规则</button></div>
      </form>
      <section class="settings-layout"><form class="panel form-panel" method="post"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="save_settings"><input type="hidden" name="return_tab" value="settings"><div class="panel-heading"><div><p class="eyebrow">机器人设置</p><h2>连接 Telegram Bot</h2></div><span class="dot <?= $settings['bot_token_encrypted'] ? 'online' : '' ?>"></span></div><label>Bot Token<input name="bot_token" type="password" placeholder="<?= $settings['bot_token_encrypted'] ? '已安全保存，留空则不修改' : '从 @BotFather 获取' ?>"><small>Token 加密存入数据库，不会在页面中回显。</small></label><label>机器人用户名<input name="bot_username" value="<?= e($settings['bot_username']) ?>" placeholder="例如 esim_reward_bot"></label><div class="form-grid"><label>奖品名称<input name="reward_name" value="<?= e($settings['reward_name']) ?>" required></label><label>每次奖励所需邀请<input name="invite_required" type="number" min="1" max="1000" value="<?= (int)$settings['invite_required'] ?>" required></label></div><label class="switch-row"><span><strong>达标后自动发放</strong><small>有可用库存时立即私发；无库存则进入待发队列。</small></span><input name="auto_send_enabled" type="checkbox" value="1" <?= $settings['auto_send_enabled'] ? 'checked' : '' ?>></label><div class="form-grid"><label>按钮 1 文案<input name="button_claim_text" value="<?= e($settings['button_claim_text']) ?>" required></label><label>按钮 2 文案<input name="button_link_text" value="<?= e($settings['button_link_text']) ?>" required></label></div><label>欢迎语<textarea name="welcome_message" rows="5" required><?= e($settings['welcome_message']) ?></textarea><small>变量：{reward} 奖品名，{required} 邀请门槛</small></label><label>邀请进度通知<textarea name="progress_message" rows="4" required><?= e($settings['progress_message']) ?></textarea><small>变量：{count}、{remaining}、{reward}、{required}</small></label><label>达标通知<textarea name="qualified_message" rows="4" required><?= e($settings['qualified_message']) ?></textarea></label><label>奖品发放消息<textarea name="reward_message" rows="4" required><?= e($settings['reward_message']) ?></textarea><small>变量：{reward}、{content}</small></label><button class="btn primary" type="submit">保存全部配置</button></form><aside class="settings-actions"><form class="panel action-card" method="post"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="test_bot"><input type="hidden" name="return_tab" value="settings"><span class="stat-icon cyan">✦</span><h3>连接检查</h3><p>验证 Token，并自动读取机器人用户名。</p><button class="btn outline" type="submit" <?= !$settings['bot_token_encrypted'] ? 'disabled' : '' ?>>测试连接</button></form><form class="panel action-card" method="post"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="set_webhook"><input type="hidden" name="return_tab" value="settings"><span class="stat-icon violet">↗</span><h3>启用 Webhook</h3><p>地址固定使用：<code><?= e(rtrim($config['app_url'], '/') . '/webhook.php') ?></code></p><button class="btn primary" type="submit" <?= !$settings['bot_token_encrypted'] ? 'disabled' : '' ?>>设置 Webhook</button></form><article class="panel cdn-card"><span>☁</span><h3>Cloudflare CDN</h3><p>站点地址固定为 <b><?= e($config['app_url']) ?></b>。请使用“完全（严格）”SSL，并绕过后台及 Webhook 缓存。</p></article></aside></section>
    <?php endif; ?>

    <?php if ($tab === 'security'): ?>
      <section class="narrow-panel panel form-panel"><div class="panel-heading"><div><p class="eyebrow">管理员</p><h2>修改登录密码</h2></div><span class="stat-icon violet">◆</span></div><form method="post"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="change_password"><input type="hidden" name="return_tab" value="security"><label>当前密码<input name="current_password" type="password" required></label><label>新密码<input name="new_password" type="password" minlength="10" required><small>至少 10 位，建议同时使用大小写字母、数字和符号。</small></label><button class="btn primary" type="submit">更新密码</button></form></section>
    <?php endif; ?>
  </main>
</div>

<dialog id="reward-dialog"><form method="post" class="dialog-card"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="send_reward"><input type="hidden" name="return_tab" value="rewards"><input type="hidden" name="reward_id" id="reward-id"><button class="dialog-close" type="button" data-dialog-close>×</button><p class="eyebrow">奖励发放</p><h2 id="reward-title">发送 <?= e($settings['reward_name']) ?></h2><p class="muted" id="reward-hint">奖品内容会立即通过机器人私发。</p><label>奖品内容 / 兑换信息<textarea name="prize_content" id="prize-content" rows="7" placeholder="输入 eSIM 激活码、二维码链接或使用说明"></textarea><small id="assigned-note"></small></label><div class="dialog-actions"><button class="btn outline" type="button" data-dialog-close>取消</button><button class="btn primary" type="submit">确认发送</button></div></form></dialog>
<script src="assets/app.js"></script>
</body></html>
