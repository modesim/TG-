const menuButton = document.querySelector('[data-menu]');
if (menuButton) {
  menuButton.addEventListener('click', () => document.body.classList.toggle('menu-open'));
  document.addEventListener('click', (event) => {
    if (!document.body.classList.contains('menu-open')) return;
    const sidebar = document.querySelector('.sidebar');
    if (sidebar && !sidebar.contains(event.target) && !menuButton.contains(event.target)) {
      document.body.classList.remove('menu-open');
    }
  });
}

const rewardDialog = document.querySelector('#reward-dialog');
document.querySelectorAll('[data-reward-id]').forEach((button) => {
  button.addEventListener('click', () => {
    document.querySelector('#reward-id').value = button.dataset.rewardId;
    document.querySelector('#reward-title').textContent = `向 ${button.dataset.rewardUser} 发放奖励`;
    const assigned = button.dataset.assigned === '1';
    const content = document.querySelector('#prize-content');
    const note = document.querySelector('#assigned-note');
    content.value = '';
    content.required = !assigned;
    content.placeholder = assigned ? '已分配库存，留空将重新发送原奖品；也可以输入新内容覆盖' : '输入 eSIM 激活码、二维码链接或使用说明';
    note.textContent = assigned ? '这条奖励已有加密库存内容，留空即可重试原内容。' : '当前没有自动分配库存，需要手动填写。';
    rewardDialog.showModal();
  });
});
document.querySelectorAll('[data-dialog-close]').forEach((button) => {
  button.addEventListener('click', () => rewardDialog?.close());
});
rewardDialog?.addEventListener('click', (event) => {
  if (event.target === rewardDialog) rewardDialog.close();
});
