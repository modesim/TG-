<?php
declare(strict_types=1);
require_once dirname(__DIR__) . '/app/bootstrap.php';
header('Content-Type: application/json; charset=utf-8');
$updateId = 0;
try {
    $settings = get_settings();
    $secret = $_SERVER['HTTP_X_TELEGRAM_BOT_API_SECRET_TOKEN'] ?? '';
    if (!$secret || !hash_equals($settings['webhook_secret'], $secret)) {
        http_response_code(401);
        echo json_encode(['ok' => false]);
        exit;
    }
    $update = json_decode(file_get_contents('php://input') ?: '{}', true, 512, JSON_THROW_ON_ERROR);
    $updateId = (int)($update['update_id'] ?? 0);
    (new BotService())->processUpdate($update);
    echo json_encode(['ok' => true]);
} catch (Throwable $exception) {
    error_log('Telegram webhook: ' . $exception->getMessage());
    if ($updateId > 0) {
        try {
            db()->prepare('DELETE FROM bot_updates WHERE update_id = ?')->execute([$updateId]);
        } catch (Throwable) {
        }
    }
    http_response_code(500);
    echo json_encode(['ok' => false]);
}
