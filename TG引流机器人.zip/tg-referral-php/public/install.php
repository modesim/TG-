<?php
declare(strict_types=1);

header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('X-Content-Type-Options: nosniff');

$root = dirname(__DIR__);
$configFile = $root . '/app/config.php';
if (is_file($configFile)) {
    header('Location: login.php');
    exit;
}

$requirements = [
    'PHP 8.1+' => PHP_VERSION_ID >= 80100,
    'PDO MySQL' => extension_loaded('pdo_mysql'),
    'cURL' => extension_loaded('curl'),
    'OpenSSL' => extension_loaded('openssl'),
    'mbstring' => extension_loaded('mbstring'),
    'app 目录可写' => is_writable($root . '/app'),
];
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        foreach ($requirements as $label => $passed) {
            if (!$passed) throw new RuntimeException('环境检查未通过：' . $label);
        }
        $appUrl = rtrim(trim((string)($_POST['app_url'] ?? '')), '/');
        if (!filter_var($appUrl, FILTER_VALIDATE_URL) || !str_starts_with($appUrl, 'https://')) {
            throw new RuntimeException('Cloudflare 域名必须填写完整的 https:// 地址');
        }
        $dbName = trim((string)($_POST['db_name'] ?? ''));
        if (!preg_match('/^[a-zA-Z0-9_]+$/', $dbName)) throw new RuntimeException('数据库名格式不正确');
        $username = trim((string)($_POST['admin_username'] ?? ''));
        $password = (string)($_POST['admin_password'] ?? '');
        if (mb_strlen($username) < 3 || mb_strlen($password) < 10) {
            throw new RuntimeException('管理员账号至少 3 位，密码至少 10 位');
        }
        $config = [
            'app_url' => $appUrl,
            'timezone' => 'Asia/Shanghai',
            'session_secret' => bin2hex(random_bytes(32)),
            'encryption_key' => bin2hex(random_bytes(32)),
            'db' => [
                'host' => trim((string)($_POST['db_host'] ?? '127.0.0.1')),
                'port' => (int)($_POST['db_port'] ?? 3306),
                'name' => $dbName,
                'user' => trim((string)($_POST['db_user'] ?? '')),
                'pass' => (string)($_POST['db_pass'] ?? ''),
                'charset' => 'utf8mb4',
            ],
        ];
        require_once $root . '/app/Database.php';
        $pdo = Database::connect($config);
        $schema = file_get_contents($root . '/database/schema.sql');
        if ($schema === false) throw new RuntimeException('无法读取数据库结构');
        foreach (array_filter(array_map('trim', explode(';', $schema))) as $sql) {
            $pdo->exec($sql);
        }
        $stmt = $pdo->prepare(
            'INSERT INTO admins (username, password_hash) VALUES (?, ?)
             ON DUPLICATE KEY UPDATE password_hash = VALUES(password_hash)'
        );
        $stmt->execute([$username, password_hash($password, PASSWORD_DEFAULT)]);
        $welcome = "欢迎参加捷克 eSIM 邀请活动！\n\n🎁 奖励：<b>{reward}</b>\n👥 每邀请 {required} 位新用户，即可获得 1 次奖励机会。\n📦 当前剩余奖品：<b>{stock}</b> 份\n\n请选择下方功能：";
        $progress = "✅ 新好友已计入邀请\n\n当前已邀请 <b>{count}</b> 人，本轮再邀请 <b>{remaining}</b> 人即可获得「{reward}」。\n📦 当前剩余奖品：<b>{stock}</b> 份";
        $qualified = "🎉 <b>邀请达标！</b>\n\n你已成功邀请 {count} 人，获得 1 次「{reward}」奖励机会。\n📦 当前剩余奖品：<b>{stock}</b> 份";
        $reward = "🎁 <b>{reward} 已发放</b>\n\n{content}\n\n请妥善保存以上信息。";
        $verification = "🛡 <b>频道验证</b>\n\n领取专属邀请码前，请先加入指定频道，然后点击“验证加入”。\n\n验证成功后，邀请关系才会生效。";
        $stmt = $pdo->prepare(
            'INSERT INTO settings
              (id, reward_name, invite_required, auto_send_enabled, channel_verification_enabled,
               verification_message, welcome_message, button_claim_text, button_link_text,
               progress_message, qualified_message, reward_message, webhook_secret)
             VALUES (1, ?, 3, 1, 1, ?, ?, ?, ?, ?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE webhook_secret = VALUES(webhook_secret)'
        );
        $stmt->execute([
            '捷克 eSIM', $verification, $welcome, '1. 领取捷克 eSIM', '2. 查看邀请链接',
            $progress, $qualified, $reward, bin2hex(random_bytes(32)),
        ]);
        $contents = "<?php\nreturn " . var_export($config, true) . ";\n";
        $tempFile = $configFile . '.tmp';
        if (file_put_contents($tempFile, $contents, LOCK_EX) === false || !rename($tempFile, $configFile)) {
            throw new RuntimeException('无法写入 app/config.php，请临时给 app 目录写入权限后重试');
        }
        header('Location: login.php?installed=1');
        exit;
    } catch (Throwable $exception) {
        $error = $exception->getMessage();
    }
}
?>
<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>安装 TG 引流中心</title><link rel="icon" href="favicon.svg" type="image/svg+xml"><link rel="stylesheet" href="assets/app.css"></head>
<body class="login-page">
<main class="install-shell">
  <section class="install-card">
    <div class="brand-icon">✦</div>
    <p class="eyebrow">宝塔面板安装向导</p>
    <h1>部署 TG 引流中心</h1>
    <p class="muted">填写一次即可完成数据库初始化与管理员创建。Cloudflare 代理域名请使用 HTTPS。</p>
    <?php if ($error): ?><div class="alert error"><?= htmlspecialchars($error, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?></div><?php endif; ?>
    <div class="requirements">
      <?php foreach ($requirements as $label => $passed): ?><span class="requirement <?= $passed ? 'ok' : 'bad' ?>"><?= $passed ? '✓' : '×' ?> <?= htmlspecialchars($label, ENT_QUOTES, 'UTF-8') ?></span><?php endforeach; ?>
    </div>
    <form method="post" class="install-form">
      <fieldset><legend>站点信息</legend><label>Cloudflare 域名（HTTPS）<input name="app_url" type="url" placeholder="https://esim.example.com" value="<?= htmlspecialchars($_POST['app_url'] ?? '', ENT_QUOTES, 'UTF-8') ?>" required></label></fieldset>
      <fieldset><legend>MySQL 数据库</legend><div class="form-grid"><label>数据库地址<input name="db_host" value="<?= htmlspecialchars($_POST['db_host'] ?? '127.0.0.1', ENT_QUOTES, 'UTF-8') ?>" required></label><label>端口<input name="db_port" type="number" value="<?= htmlspecialchars($_POST['db_port'] ?? '3306', ENT_QUOTES, 'UTF-8') ?>" required></label></div><div class="form-grid"><label>数据库名<input name="db_name" value="<?= htmlspecialchars($_POST['db_name'] ?? '', ENT_QUOTES, 'UTF-8') ?>" required></label><label>数据库用户<input name="db_user" value="<?= htmlspecialchars($_POST['db_user'] ?? '', ENT_QUOTES, 'UTF-8') ?>" required></label></div><label>数据库密码<input name="db_pass" type="password" required></label></fieldset>
      <fieldset><legend>管理员</legend><div class="form-grid"><label>管理员账号<input name="admin_username" minlength="3" required></label><label>管理员密码<input name="admin_password" type="password" minlength="10" required></label></div></fieldset>
      <button class="btn primary wide" type="submit">检查并完成安装</button>
    </form>
    <p class="install-note">安装完成后请把 <code>app/config.php</code> 权限设为 600，并在 Cloudflare 中排除后台和 Webhook 缓存。</p>
  </section>
</main>
</body></html>
